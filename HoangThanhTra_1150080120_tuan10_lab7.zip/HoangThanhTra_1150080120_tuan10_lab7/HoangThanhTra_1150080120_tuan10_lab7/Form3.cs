﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace HoangThanhTra_1150080120_tuan10_lab7
{
    public partial class Form3 : Form
    {
        // Chuỗi kết nối
        string strCon = @"Data Source=DESKTOP-O5A1RCH\THANHTRA;
                          Initial Catalog=QuanLyBanSach;
                          Integrated Security=True;
                          Encrypt=False;
                          TrustServerCertificate=True;";

        // Đối tượng kết nối
        SqlConnection sqlCon = null;

        public Form3()
        {
            InitializeComponent();
        }

        // Hàm mở kết nối
        private void MoKetNoi()
        {
            if (sqlCon == null)
            {
                sqlCon = new SqlConnection(strCon);
            }
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
        }

        // Hàm đóng kết nối
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
            {
                sqlCon.Close();
            }
        }

        // Hàm load dữ liệu
        private void LoadData()
        {
            try
            {
                MoKetNoi();
                string sql = "SELECT * FROM NhaXuatBan";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, sqlCon);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "tblNhaXuatBan");
                dgvDanhSach.DataSource = ds.Tables["tblNhaXuatBan"];
                dgvDanhSach.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi load dữ liệu: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // Hàm xóa nội dung các TextBox
        private void ClearTextBoxes()
        {
            txtMaXB.Clear();
            txtTenXB.Clear();
            txtDiaChi.Clear();
        }

        // Sự kiện Load Form
        private void Form3_Load(object? sender, EventArgs e)
        {
            LoadData();
            ClearTextBoxes();
            
            // Thêm event SelectionChanged để đảm bảo luôn load được dữ liệu
            dgvDanhSach.SelectionChanged += DgvDanhSach_SelectionChanged;
        }

        // Sự kiện khi thay đổi selection trong DataGridView
        private void DgvDanhSach_SelectionChanged(object? sender, EventArgs e)
        {
            try
            {
                if (dgvDanhSach.CurrentRow != null && !dgvDanhSach.CurrentRow.IsNewRow)
                {
                    DataGridViewRow row = dgvDanhSach.CurrentRow;
                    
                    if (row.Cells.Count >= 3)
                    {
                        txtMaXB.Text = row.Cells[0].Value?.ToString() ?? "";
                        txtTenXB.Text = row.Cells[1].Value?.ToString() ?? "";
                        txtDiaChi.Text = row.Cells[2].Value?.ToString() ?? "";
                    }
                }
            }
            catch (Exception ex)
            {
                // Không hiển thị lỗi để tránh spam message box
                System.Diagnostics.Debug.WriteLine("Lỗi SelectionChanged: " + ex.Message);
            }
        }

        // Sự kiện click vào dòng trong DataGridView
        private void dgvDanhSach_CellClick(object? sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // Kiểm tra index hợp lệ
                if (e.RowIndex >= 0 && e.RowIndex < dgvDanhSach.Rows.Count)
                {
                    DataGridViewRow row = dgvDanhSach.Rows[e.RowIndex];
                    
                    // Kiểm tra row không null và có dữ liệu
                    if (row != null && !row.IsNewRow)
                    {
                        // Truy cập bằng index để tránh lỗi tên cột
                        if (row.Cells.Count >= 3)
                        {
                            txtMaXB.Text = row.Cells[0].Value?.ToString() ?? "";
                            txtTenXB.Text = row.Cells[1].Value?.ToString() ?? "";
                            txtDiaChi.Text = row.Cells[2].Value?.ToString() ?? "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi chọn dòng: " + ex.Message, 
                    "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Nút Sửa (chỉnh sửa thông tin)
        private void btnSua_Click(object? sender, EventArgs e)
        {
            try
            {
                // Kiểm tra dữ liệu nhập
                if (string.IsNullOrWhiteSpace(txtMaXB.Text))
                {
                    MessageBox.Show("Vui lòng chọn NXB cần sửa!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtTenXB.Text))
                {
                    MessageBox.Show("Vui lòng nhập Tên NXB!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtTenXB.Focus();
                    return;
                }

                MoKetNoi();

                // Thực hiện cập nhật
                string sql = "UPDATE NhaXuatBan SET TenXB = @TenXB, DiaChi = @DiaChi WHERE MaXB = @MaXB";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaXB", txtMaXB.Text.Trim());
                cmd.Parameters.AddWithValue("@TenXB", txtTenXB.Text.Trim());
                cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text.Trim());

                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                {
                    MessageBox.Show("Cập nhật dữ liệu thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Không tìm thấy dữ liệu để cập nhật!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }
    }
}
