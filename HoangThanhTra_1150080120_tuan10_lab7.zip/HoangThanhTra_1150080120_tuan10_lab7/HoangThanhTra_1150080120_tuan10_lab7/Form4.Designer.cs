﻿namespace HoangThanhTra_1150080120_tuan10_lab7
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblDanhSach = new Label();
            dgvDanhSach = new DataGridView();
            btnXoaDuLieu = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvDanhSach).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblTitle.ForeColor = Color.DarkBlue;
            lblTitle.Location = new Point(132, 24);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(325, 32);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Xóa dữ liệu trong database";
            // 
            // lblDanhSach
            // 
            lblDanhSach.AutoSize = true;
            lblDanhSach.Font = new Font("Segoe UI", 10F);
            lblDanhSach.Location = new Point(12, 80);
            lblDanhSach.Name = "lblDanhSach";
            lblDanhSach.Size = new Size(200, 23);
            lblDanhSach.TabIndex = 1;
            lblDanhSach.Text = "Danh sách nhà xuất bản:";
            // 
            // dgvDanhSach
            // 
            dgvDanhSach.AllowUserToAddRows = false;
            dgvDanhSach.AllowUserToDeleteRows = false;
            dgvDanhSach.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDanhSach.BackgroundColor = Color.LightGray;
            dgvDanhSach.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDanhSach.Location = new Point(12, 110);
            dgvDanhSach.Name = "dgvDanhSach";
            dgvDanhSach.ReadOnly = true;
            dgvDanhSach.RowHeadersWidth = 51;
            dgvDanhSach.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvDanhSach.Size = new Size(560, 220);
            dgvDanhSach.TabIndex = 2;
            dgvDanhSach.CellClick += dgvDanhSach_CellClick;
            // 
            // btnXoaDuLieu
            // 
            btnXoaDuLieu.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnXoaDuLieu.Location = new Point(246, 350);
            btnXoaDuLieu.Name = "btnXoaDuLieu";
            btnXoaDuLieu.Size = new Size(100, 35);
            btnXoaDuLieu.TabIndex = 3;
            btnXoaDuLieu.Text = "Xóa dữ liệu";
            btnXoaDuLieu.UseVisualStyleBackColor = true;
            btnXoaDuLieu.Click += btnXoaDuLieu_Click;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(584, 411);
            Controls.Add(btnXoaDuLieu);
            Controls.Add(dgvDanhSach);
            Controls.Add(lblDanhSach);
            Controls.Add(lblTitle);
            Name = "Form4";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Xóa dữ liệu trong database";
            Load += Form4_Load;
            ((System.ComponentModel.ISupportInitialize)dgvDanhSach).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label lblDanhSach;
        private DataGridView dgvDanhSach;
        private Button btnXoaDuLieu;
    }
}