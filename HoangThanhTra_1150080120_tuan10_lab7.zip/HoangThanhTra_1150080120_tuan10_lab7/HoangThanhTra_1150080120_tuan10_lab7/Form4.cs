﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace HoangThanhTra_1150080120_tuan10_lab7
{
    public partial class Form4 : Form
    {
        // Chuoi ket noi - sử dụng giống các form khác
        string strCon = @"Data Source=DESKTOP-O5A1RCH\THANHTRA;
                          Initial Catalog=QuanLyBanSach;
                          Integrated Security=True;
                          Encrypt=False;
                          TrustServerCertificate=True;";

        // Doi tuong ket noi
        SqlConnection? sqlCon = null;
        SqlDataAdapter? adapter = null;
        DataSet? ds = null;

        public Form4()
        {
            InitializeComponent();
        }

        // Ham mo ket noi
        private void MoKetNoi()
        {
            try
            {
                if (sqlCon == null)
                {
                    sqlCon = new SqlConnection(strCon);
                }

                if (sqlCon.State == ConnectionState.Closed)
                {
                    sqlCon.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối database: " + ex.Message, "Lỗi kết nối",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw; // Re-throw để caller có thể handle
            }
        }

        // Ham dong ket noi
        private void DongKetNoi()
        {
            try
            {
                if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
            catch (Exception ex)
            {
                // Log error nhưng không hiển thị MessageBox để tránh spam
                System.Diagnostics.Debug.WriteLine("Lỗi đóng kết nối: " + ex.Message);
            }
        }

        // Ham hien thi du lieu tren datagridview
        private void HienThiDuLieu()
        {
            try
            {
                // Thêm cursor loading
                this.Cursor = Cursors.WaitCursor;
                
                MoKetNoi();

                string query = "SELECT * FROM NhaXuatBan";

                adapter = new SqlDataAdapter(query, sqlCon);
                SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                ds = new DataSet();
                adapter.Fill(ds, "tblNhaXuatBan");
                dgvDanhSach.DataSource = ds.Tables["tblNhaXuatBan"];
                
                // Auto resize columns
                dgvDanhSach.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"Lỗi SQL: {sqlEx.Message}\nMã lỗi: {sqlEx.Number}", "Lỗi Database",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị dữ liệu: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
                this.Cursor = Cursors.Default;
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            try
            {
                HienThiDuLieu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi khởi tạo Form4: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                // Đóng form nếu không load được dữ liệu
                DialogResult result = MessageBox.Show("Không thể tải dữ liệu. Bạn có muốn đóng form?", "Xác nhận",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                
                if (result == DialogResult.Yes)
                {
                    this.Close();
                }
            }
        }

        int vt = -1;

        private void dgvDanhSach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.RowIndex < dgvDanhSach.Rows.Count)
                {
                    vt = e.RowIndex;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi chọn dòng: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnXoaDuLieu_Click(object sender, EventArgs e)
        {
            try
            {
                if (vt == -1)
                {
                    MessageBox.Show("Bạn chưa chọn dữ liệu để xóa!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult result = MessageBox.Show("Bạn có thực sự muốn xóa hay không?", "Cảnh báo",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    XoaDuLieu();
                    HienThiDuLieu();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi trong quá trình xóa: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Ham xoa du lieu
        private void XoaDuLieu()
        {
            try
            {
                if (ds != null && 
                    ds.Tables["tblNhaXuatBan"] != null && 
                    adapter != null &&
                    vt >= 0 && 
                    vt < ds.Tables["tblNhaXuatBan"].Rows.Count)
                {
                    DataRow row = ds.Tables["tblNhaXuatBan"].Rows[vt];
                    row.Delete();
                    
                    // Thêm cursor loading
                    this.Cursor = Cursors.WaitCursor;
                    
                    int kq = adapter.Update(ds.Tables["tblNhaXuatBan"]);

                    if (kq > 0)
                    {
                        MessageBox.Show("Xóa dữ liệu thành công!", "Thành công",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        vt = -1; // Reset selection
                    }
                    else
                    {
                        MessageBox.Show("Xóa dữ liệu không thành công!", "Lỗi",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Không có dữ liệu để xóa!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Number == 547) // Foreign key constraint error
                {
                    MessageBox.Show("Không thể xóa dữ liệu này vì có ràng buộc khóa ngoại!", "Lỗi ràng buộc",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show($"Lỗi SQL khi xóa: {sqlEx.Message}\nMã lỗi: {sqlEx.Number}", "Lỗi SQL",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa dữ liệu: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }
    }
}