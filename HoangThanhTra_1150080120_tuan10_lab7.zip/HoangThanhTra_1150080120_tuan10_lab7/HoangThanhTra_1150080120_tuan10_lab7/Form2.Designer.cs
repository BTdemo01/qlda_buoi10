﻿namespace HoangThanhTra_1150080120_tuan10_lab7
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblDanhSach = new Label();
            lblNhapThongTin = new Label();
            lblMaXB = new Label();
            lblTenXB = new Label();
            lblDiaChi = new Label();
            txtMaXB = new TextBox();
            txtTenXB = new TextBox();
            txtDiaChi = new TextBox();
            btnThem = new Button();
            dgvDanhSach = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvDanhSach).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold);
            lblTitle.ForeColor = Color.Blue;
            lblTitle.Location = new Point(234, 15);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(250, 24);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Thêm dữ liệu vào database";
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblDanhSach
            // 
            lblDanhSach.AutoSize = true;
            lblDanhSach.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            lblDanhSach.Location = new Point(25, 55);
            lblDanhSach.Name = "lblDanhSach";
            lblDanhSach.Size = new Size(160, 15);
            lblDanhSach.TabIndex = 1;
            lblDanhSach.Text = "Danh sách nhà xuất bản:";
            // 
            // lblNhapThongTin
            // 
            lblNhapThongTin.AutoSize = true;
            lblNhapThongTin.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            lblNhapThongTin.Location = new Point(420, 55);
            lblNhapThongTin.Name = "lblNhapThongTin";
            lblNhapThongTin.Size = new Size(103, 15);
            lblNhapThongTin.TabIndex = 2;
            lblNhapThongTin.Text = "Nhập thông tin:";
            // 
            // lblMaXB
            // 
            lblMaXB.AutoSize = true;
            lblMaXB.Font = new Font("Microsoft Sans Serif", 9F);
            lblMaXB.Location = new Point(420, 90);
            lblMaXB.Name = "lblMaXB";
            lblMaXB.Size = new Size(53, 15);
            lblMaXB.TabIndex = 3;
            lblMaXB.Text = "Mã NXB:";
            // 
            // lblTenXB
            // 
            lblTenXB.AutoSize = true;
            lblTenXB.Font = new Font("Microsoft Sans Serif", 9F);
            lblTenXB.Location = new Point(420, 150);
            lblTenXB.Name = "lblTenXB";
            lblTenXB.Size = new Size(58, 15);
            lblTenXB.TabIndex = 4;
            lblTenXB.Text = "Tên NXB:";
            // 
            // lblDiaChi
            // 
            lblDiaChi.AutoSize = true;
            lblDiaChi.Font = new Font("Microsoft Sans Serif", 9F);
            lblDiaChi.Location = new Point(420, 210);
            lblDiaChi.Name = "lblDiaChi";
            lblDiaChi.Size = new Size(50, 15);
            lblDiaChi.TabIndex = 5;
            lblDiaChi.Text = "Địa chỉ:";
            // 
            // txtMaXB
            // 
            txtMaXB.Font = new Font("Microsoft Sans Serif", 9F);
            txtMaXB.Location = new Point(420, 110);
            txtMaXB.Name = "txtMaXB";
            txtMaXB.Size = new Size(240, 21);
            txtMaXB.TabIndex = 6;
            // 
            // txtTenXB
            // 
            txtTenXB.Font = new Font("Microsoft Sans Serif", 9F);
            txtTenXB.Location = new Point(420, 170);
            txtTenXB.Name = "txtTenXB";
            txtTenXB.Size = new Size(240, 21);
            txtTenXB.TabIndex = 7;
            // 
            // txtDiaChi
            // 
            txtDiaChi.Font = new Font("Microsoft Sans Serif", 9F);
            txtDiaChi.Location = new Point(420, 230);
            txtDiaChi.Name = "txtDiaChi";
            txtDiaChi.Size = new Size(240, 21);
            txtDiaChi.TabIndex = 8;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            btnThem.Location = new Point(490, 280);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(100, 30);
            btnThem.TabIndex = 9;
            btnThem.Text = "Thêm dữ liệu";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // dgvDanhSach
            // 
            dgvDanhSach.AllowUserToAddRows = false;
            dgvDanhSach.AllowUserToDeleteRows = false;
            dgvDanhSach.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDanhSach.BackgroundColor = Color.White;
            dgvDanhSach.BorderStyle = BorderStyle.Fixed3D;
            dgvDanhSach.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDanhSach.Location = new Point(25, 75);
            dgvDanhSach.MultiSelect = false;
            dgvDanhSach.Name = "dgvDanhSach";
            dgvDanhSach.ReadOnly = true;
            dgvDanhSach.RowHeadersWidth = 25;
            dgvDanhSach.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvDanhSach.Size = new Size(370, 320);
            dgvDanhSach.TabIndex = 10;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(700, 420);
            Controls.Add(dgvDanhSach);
            Controls.Add(btnThem);
            Controls.Add(txtDiaChi);
            Controls.Add(txtTenXB);
            Controls.Add(txtMaXB);
            Controls.Add(lblDiaChi);
            Controls.Add(lblTenXB);
            Controls.Add(lblMaXB);
            Controls.Add(lblNhapThongTin);
            Controls.Add(lblDanhSach);
            Controls.Add(lblTitle);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Thực hành 2 - Thêm dữ liệu NXB";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)dgvDanhSach).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label lblDanhSach;
        private Label lblNhapThongTin;
        private Label lblMaXB;
        private Label lblTenXB;
        private Label lblDiaChi;
        private TextBox txtMaXB;
        private TextBox txtTenXB;
        private TextBox txtDiaChi;
        private Button btnThem;
        private DataGridView dgvDanhSach;
    }
}
