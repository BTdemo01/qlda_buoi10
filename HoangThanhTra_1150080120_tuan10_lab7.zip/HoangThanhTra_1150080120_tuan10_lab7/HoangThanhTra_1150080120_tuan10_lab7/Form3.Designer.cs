﻿namespace HoangThanhTra_1150080120_tuan10_lab7
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblDanhSach = new Label();
            lblChinhSua = new Label();
            lblMaXB = new Label();
            lblTenXB = new Label();
            lblDiaChi = new Label();
            txtMaXB = new TextBox();
            txtTenXB = new TextBox();
            txtDiaChi = new TextBox();
            btnChinhSua = new Button();
            dgvDanhSach = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvDanhSach).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold);
            lblTitle.ForeColor = Color.Blue;
            lblTitle.Location = new Point(321, 20);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(321, 29);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Chỉnh sửa thông tin dữ liệu";
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblDanhSach
            // 
            lblDanhSach.AutoSize = true;
            lblDanhSach.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            lblDanhSach.Location = new Point(29, 73);
            lblDanhSach.Name = "lblDanhSach";
            lblDanhSach.Size = new Size(193, 18);
            lblDanhSach.TabIndex = 1;
            lblDanhSach.Text = "Danh sách nhà xuất bản:";
            // 
            // lblChinhSua
            // 
            lblChinhSua.AutoSize = true;
            lblChinhSua.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            lblChinhSua.Location = new Point(480, 73);
            lblChinhSua.Name = "lblChinhSua";
            lblChinhSua.Size = new Size(158, 18);
            lblChinhSua.TabIndex = 2;
            lblChinhSua.Text = "Chỉnh sửa thông tin:";
            // 
            // lblMaXB
            // 
            lblMaXB.AutoSize = true;
            lblMaXB.Font = new Font("Microsoft Sans Serif", 9F);
            lblMaXB.Location = new Point(480, 120);
            lblMaXB.Name = "lblMaXB";
            lblMaXB.Size = new Size(68, 18);
            lblMaXB.TabIndex = 3;
            lblMaXB.Text = "Mã NXB:";
            // 
            // lblTenXB
            // 
            lblTenXB.AutoSize = true;
            lblTenXB.Font = new Font("Microsoft Sans Serif", 9F);
            lblTenXB.Location = new Point(480, 200);
            lblTenXB.Name = "lblTenXB";
            lblTenXB.Size = new Size(72, 18);
            lblTenXB.TabIndex = 4;
            lblTenXB.Text = "Tên NXB:";
            // 
            // lblDiaChi
            // 
            lblDiaChi.AutoSize = true;
            lblDiaChi.Font = new Font("Microsoft Sans Serif", 9F);
            lblDiaChi.Location = new Point(480, 280);
            lblDiaChi.Name = "lblDiaChi";
            lblDiaChi.Size = new Size(57, 18);
            lblDiaChi.TabIndex = 5;
            lblDiaChi.Text = "Địa chỉ:";
            // 
            // txtMaXB
            // 
            txtMaXB.Font = new Font("Microsoft Sans Serif", 9F);
            txtMaXB.Location = new Point(554, 116);
            txtMaXB.Margin = new Padding(3, 4, 3, 4);
            txtMaXB.Name = "txtMaXB";
            txtMaXB.ReadOnly = true;
            txtMaXB.Size = new Size(228, 24);
            txtMaXB.TabIndex = 6;
            // 
            // txtTenXB
            // 
            txtTenXB.Font = new Font("Microsoft Sans Serif", 9F);
            txtTenXB.Location = new Point(554, 196);
            txtTenXB.Margin = new Padding(3, 4, 3, 4);
            txtTenXB.Name = "txtTenXB";
            txtTenXB.Size = new Size(228, 24);
            txtTenXB.TabIndex = 7;
            // 
            // txtDiaChi
            // 
            txtDiaChi.Font = new Font("Microsoft Sans Serif", 9F);
            txtDiaChi.Location = new Point(554, 276);
            txtDiaChi.Margin = new Padding(3, 4, 3, 4);
            txtDiaChi.Name = "txtDiaChi";
            txtDiaChi.Size = new Size(228, 24);
            txtDiaChi.TabIndex = 8;
            // 
            // btnChinhSua
            // 
            btnChinhSua.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            btnChinhSua.Location = new Point(554, 346);
            btnChinhSua.Margin = new Padding(3, 4, 3, 4);
            btnChinhSua.Name = "btnChinhSua";
            btnChinhSua.Size = new Size(185, 40);
            btnChinhSua.TabIndex = 9;
            btnChinhSua.Text = "Chỉnh sửa thông tin";
            btnChinhSua.UseVisualStyleBackColor = true;
            btnChinhSua.Click += btnSua_Click;
            // 
            // dgvDanhSach
            // 
            dgvDanhSach.AllowUserToAddRows = false;
            dgvDanhSach.AllowUserToDeleteRows = false;
            dgvDanhSach.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDanhSach.BackgroundColor = Color.White;
            dgvDanhSach.BorderStyle = BorderStyle.Fixed3D;
            dgvDanhSach.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDanhSach.Location = new Point(29, 100);
            dgvDanhSach.Margin = new Padding(3, 4, 3, 4);
            dgvDanhSach.MultiSelect = false;
            dgvDanhSach.Name = "dgvDanhSach";
            dgvDanhSach.ReadOnly = true;
            dgvDanhSach.RowHeadersWidth = 25;
            dgvDanhSach.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvDanhSach.Size = new Size(423, 427);
            dgvDanhSach.TabIndex = 10;
            dgvDanhSach.CellClick += dgvDanhSach_CellClick;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(823, 560);
            Controls.Add(dgvDanhSach);
            Controls.Add(btnChinhSua);
            Controls.Add(txtDiaChi);
            Controls.Add(txtTenXB);
            Controls.Add(txtMaXB);
            Controls.Add(lblDiaChi);
            Controls.Add(lblTenXB);
            Controls.Add(lblMaXB);
            Controls.Add(lblChinhSua);
            Controls.Add(lblDanhSach);
            Controls.Add(lblTitle);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 4, 3, 4);
            MaximizeBox = false;
            Name = "Form3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form3_Load;
            ((System.ComponentModel.ISupportInitialize)dgvDanhSach).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label lblDanhSach;
        private Label lblChinhSua;
        private Label lblMaXB;
        private Label lblTenXB;
        private Label lblDiaChi;
        private TextBox txtMaXB;
        private TextBox txtTenXB;
        private TextBox txtDiaChi;
        private Button btnChinhSua;
        private DataGridView dgvDanhSach;
    }
}
