﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace HoangThanhTra_1150080120_tuan10_lab7
{
    public partial class Form2 : Form
    {
        // Chuỗi kết nối
        string strCon = @"Data Source=DESKTOP-O5A1RCH\THANHTRA;
                          Initial Catalog=QuanLyBanSach;
                          Integrated Security=True;
                          Encrypt=False;
                          TrustServerCertificate=True;";

        // Đối tượng kết nối và dữ liệu
        SqlConnection? sqlCon = null;
        SqlDataAdapter? adapter = null;
        DataSet? ds = null;

        public Form2()
        {
            InitializeComponent();
        }

        // Hàm mở kết nối
        private void MoKetNoi()
        {
            if (sqlCon == null)
            {
                sqlCon = new SqlConnection(strCon);
            }
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
        }

        // Hàm đóng kết nối
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
            {
                sqlCon.Close();
            }
        }

        // Hàm xóa dữ liệu trên các control
        private void XoaDuLieuForm()
        {
            txtMaXB.Text = "";
            txtTenXB.Text = "";
            txtDiaChi.Text = "";
            txtMaXB.Focus();
        }

        // Hàm hiển thị dữ liệu lên DataGridView
        private void HienThiDuLieu()
        {
            try
            {
                MoKetNoi();
                string query = "SELECT * FROM NhaXuatBan";

                adapter = new SqlDataAdapter(query, sqlCon);
                SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                ds = new DataSet();

                adapter.Fill(ds, "tblNhaXuatBan");
                dgvDanhSach.DataSource = ds.Tables["tblNhaXuatBan"];
                dgvDanhSach.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị dữ liệu: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Sự kiện Form Load
        private void Form2_Load(object sender, EventArgs e)
        {
            HienThiDuLieu();
            XoaDuLieuForm();
        }

        // Sự kiện click nút Thêm dữ liệu
        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                // Kiểm tra dữ liệu nhập
                if (string.IsNullOrWhiteSpace(txtMaXB.Text))
                {
                    MessageBox.Show("Vui lòng nhập Mã NXB!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaXB.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtTenXB.Text))
                {
                    MessageBox.Show("Vui lòng nhập Tên NXB!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtTenXB.Focus();
                    return;
                }

                MoKetNoi();

                // Kiểm tra mã NXB đã tồn tại chưa
                string sqlCheck = "SELECT COUNT(*) FROM NhaXuatBan WHERE MaXB = @MaXB";
                SqlCommand cmdCheck = new SqlCommand(sqlCheck, sqlCon);
                cmdCheck.Parameters.AddWithValue("@MaXB", txtMaXB.Text.Trim());
                int count = (int)cmdCheck.ExecuteScalar();

                if (count > 0)
                {
                    MessageBox.Show("Mã NXB đã tồn tại!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaXB.Focus();
                    return;
                }

                // Thực hiện thêm
                string sql = @"INSERT INTO NhaXuatBan (MaXB, TenXB, DiaChi) 
                              VALUES (@MaXB, @TenXB, @DiaChi)";
                
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaXB", txtMaXB.Text.Trim());
                cmd.Parameters.AddWithValue("@TenXB", txtTenXB.Text.Trim());
                cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text.Trim());

                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                {
                    MessageBox.Show("Thêm dữ liệu thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    HienThiDuLieu();
                    XoaDuLieuForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }
    }
}

