﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

// Sử dụng namespace bạn yêu cầu
namespace HoangThanhTra_1150080120_tuan10_lab7
{
    public partial class Form1 : Form
    {
        // Sử dụng chuỗi kết nối bạn yêu cầu
        string strCon = @"Data Source=DESKTOP-O5A1RCH\THANHTRA;
                          Initial Catalog=QuanLyBanSach;
                          Integrated Security=True;
                          Encrypt=False;
                          TrustServerCertificate=True;";

        // Đối tượng kết nối
        SqlConnection sqlCon = null;

        public Form1()
        {
            InitializeComponent();
        }

        // Hàm mở kết nối
        private void MoKetNoi()
        {
            if (sqlCon == null)
            {
                sqlCon = new SqlConnection(strCon);
            }
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
        }

        // Hàm đóng kết nối
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
            {
                sqlCon.Close();
            }
        }

        // Sự kiện click nút Hiển thị
        private void btnHienThi_Click(object sender, EventArgs e)
        {
            try
            {
                // Mở kết nối
                MoKetNoi();

                // Câu lệnh SQL để lấy dữ liệu từ bảng NhaXuatBan
                string sql = "SELECT * FROM NhaXuatBan";

                // Sử dụng SqlDataAdapter để thực thi truy vấn
                SqlDataAdapter adapter = new SqlDataAdapter(sql, sqlCon);

                // Tạo DataSet để chứa dữ liệu
                DataSet ds = new DataSet();

                // Đổ dữ liệu vào DataSet
                adapter.Fill(ds, "tblNhaXuatBan");

                // Gán nguồn dữ liệu cho DataGridView
                dgvDanhSach.DataSource = ds.Tables["tblNhaXuatBan"];

                // Tự động điều chỉnh độ rộng cột
                dgvDanhSach.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                MessageBox.Show("Hiển thị dữ liệu thành công!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Đóng kết nối
                DongKetNoi();
            }
        }
    }
}