﻿namespace HoangThanhTra_1150080120_tuan10_lab7
{
    partial class FormMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnThucHanh1 = new Button();
            btnThucHanh2 = new Button();
            btnThucHanh3 = new Button();
            btnThucHanh4 = new Button();
            btnThoat = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // btnThucHanh1
            // 
            btnThucHanh1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnThucHanh1.Location = new Point(120, 120);
            btnThucHanh1.Name = "btnThucHanh1";
            btnThucHanh1.Size = new Size(260, 60);
            btnThucHanh1.TabIndex = 0;
            btnThucHanh1.Text = "Form 1\r\nHiển thị dữ liệu";
            btnThucHanh1.UseVisualStyleBackColor = true;
            btnThucHanh1.Click += btnThucHanh1_Click;
            // 
            // btnThucHanh2
            // 
            btnThucHanh2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnThucHanh2.Location = new Point(120, 200);
            btnThucHanh2.Name = "btnThucHanh2";
            btnThucHanh2.Size = new Size(260, 60);
            btnThucHanh2.TabIndex = 1;
            btnThucHanh2.Text = "Form 2\r\nThêm dữ liệu NXB";
            btnThucHanh2.UseVisualStyleBackColor = true;
            btnThucHanh2.Click += btnThucHanh2_Click;
            // 
            // btnThucHanh3
            // 
            btnThucHanh3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnThucHanh3.Location = new Point(120, 280);
            btnThucHanh3.Name = "btnThucHanh3";
            btnThucHanh3.Size = new Size(260, 60);
            btnThucHanh3.TabIndex = 2;
            btnThucHanh3.Text = "Form 3\r\nChỉnh sửa NXB";
            btnThucHanh3.UseVisualStyleBackColor = true;
            btnThucHanh3.Click += btnThucHanh3_Click;
            // 
            // btnThucHanh4
            // 
            btnThucHanh4.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnThucHanh4.Location = new Point(120, 360);
            btnThucHanh4.Name = "btnThucHanh4";
            btnThucHanh4.Size = new Size(260, 60);
            btnThucHanh4.TabIndex = 3;
            btnThucHanh4.Text = "Form 4\r\nXóa dữ liệu trong database";
            btnThucHanh4.UseVisualStyleBackColor = true;
            btnThucHanh4.Click += btnThucHanh4_Click;
            // 
            // btnThoat
            // 
            btnThoat.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnThoat.Location = new Point(120, 440);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(260, 60);
            btnThoat.TabIndex = 4;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;
            btnThoat.Click += btnThoat_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            label1.ForeColor = Color.Blue;
            label1.Location = new Point(100, 20);
            label1.Name = "label1";
            label1.Size = new Size(300, 41);
            label1.TabIndex = 5;
            label1.Text = "LAB 7 - WINFORM";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label2.Location = new Point(80, 65);
            label2.Name = "label2";
            label2.Size = new Size(340, 28);
            label2.TabIndex = 6;
            label2.Text = "Kết nối Cơ sở dữ liệu nâng cao";
            // 
            // FormMenu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(500, 530);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnThoat);
            Controls.Add(btnThucHanh4);
            Controls.Add(btnThucHanh3);
            Controls.Add(btnThucHanh2);
            Controls.Add(btnThucHanh1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "FormMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Menu Chính - Lab 7";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnThucHanh1;
        private Button btnThucHanh2;
        private Button btnThucHanh3;
        private Button btnThucHanh4;
        private Button btnThoat;
        private Label label1;
        private Label label2;
    }
}
