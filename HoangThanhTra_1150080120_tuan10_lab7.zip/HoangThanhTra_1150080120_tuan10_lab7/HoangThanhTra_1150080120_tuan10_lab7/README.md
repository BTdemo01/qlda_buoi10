# LAB 7 - WINFORM K?T N?I C? S? D? LI?U N�NG CAO

## ?? Th�ng tin sinh vi�n
- **H? t�n**: Ho�ng Thanh Tr�
- **MSSV**: 1150080120
- **Tu?n**: 10
- **Lab**: 7

## ?? M� t? d? �n
?ng d?ng WinForm k?t n?i v� thao t�c v?i C? s? d? li?u SQL Server - Qu?n l� Nh� Xu?t B?n

## ?? C?u tr�c Project

### Form Menu (FormMenu)
- Form ch�nh ?? ch?n c�c th?c h�nh
- Ch?c n?ng:
  - M? Th?c h�nh 1
  - M? Th?c h�nh 2
  - Tho�t ch??ng tr�nh

### Th?c h�nh 1 (Form1)
**Ch?c n?ng**: Hi?n th? d? li?u t? CSDL
- ? K?t n?i SQL Server
- ? Hi?n th? to�n b? d? li?u b?ng NhaXuatBan
- ? S? d?ng SqlDataAdapter v� DataSet
- ? Hi?n th? d? li?u tr�n DataGridView

**Th�nh ph?n giao di?n**:
- Button "Hi?n Th?": Load d? li?u t? database
- DataGridView: Hi?n th? danh s�ch Nh� Xu?t B?n

### Th?c h�nh 2 (Form2)
**Ch?c n?ng**: Qu?n l� CRUD (Create, Read, Update, Delete) ??y ??
- ? Th�m Nh� Xu?t B?n m?i
- ? S?a th�ng tin Nh� Xu?t B?n
- ? X�a Nh� Xu?t B?n
- ? L�m m?i d? li?u
- ? Tho�t ch??ng tr�nh

**Th�nh ph?n giao di?n**:
- **GroupBox "Th�ng tin Nh� Xu?t B?n"**:
  - TextBox: M� NXB
  - TextBox: T�n NXB
  - TextBox: ??a ch?
  - TextBox: ?i?n tho?i

- **GroupBox "Ch?c n?ng"**:
  - Button Th�m: Th�m NXB m?i
  - Button S?a: C?p nh?t th�ng tin NXB
  - Button X�a: X�a NXB ?� ch?n
  - Button L�m m?i: Reset form
  - Button Tho�t: ?�ng form

- **DataGridView**: Hi?n th? danh s�ch NXB

## ?? Y�u c?u h? th?ng
- .NET 8.0
- SQL Server
- Microsoft.Data.SqlClient 6.1.2

## ??? C? s? d? li?u
**Database**: QuanLyBanSach

**B?ng**: NhaXuatBan
```sql
CREATE TABLE NhaXuatBan (
    MaNXB NVARCHAR(10) PRIMARY KEY,
    TenNXB NVARCHAR(100) NOT NULL,
    DiaChi NVARCHAR(200),
    DienThoai NVARCHAR(20)
)
```

## ?? Chu?i k?t n?i
```csharp
string strCon = @"Data Source=DESKTOP-O5A1RCH\THANHTRA;
                  Initial Catalog=QuanLyBanSach;
                  Integrated Security=True;
                  Encrypt=False;
                  TrustServerCertificate=True;";
```

**L?u �**: C?n thay ??i `Data Source` ph� h?p v?i SQL Server c?a b?n.

## ?? C�ch s? d?ng

### 1. Ch?y ?ng d?ng
- M? project trong Visual Studio
- Nh?n F5 ho?c click Start
- Form Menu s? hi?n th?

### 2. Th?c h�nh 1 - Hi?n th? d? li?u
- Click n�t "Th?c h�nh 1"
- Click n�t "Hi?n Th?" ?? xem d? li?u

### 3. Th?c h�nh 2 - Qu?n l� NXB

#### Th�m NXB m?i:
1. Nh?p ??y ?? th�ng tin (M� NXB b?t bu?c)
2. Click n�t "Th�m"
3. H? th?ng ki?m tra tr�ng m� v� th�m v�o database

#### S?a th�ng tin NXB:
1. Click ch?n d�ng c?n s?a tr�n DataGridView
2. Th�ng tin s? hi?n th? l�n c�c TextBox
3. Ch?nh s?a th�ng tin c?n thi?t
4. Click n�t "S?a"
5. X�c nh?n ?? c?p nh?t

#### X�a NXB:
1. Click ch?n d�ng c?n x�a
2. Click n�t "X�a"
3. X�c nh?n ?? x�a
4. **Ch� �**: Kh�ng th? x�a n?u c� r�ng bu?c kh�a ngo?i

#### L�m m?i:
- Click n�t "L�m m?i" ?? x�a tr?ng form v� reload d? li?u

## ? T�nh n?ng n?i b?t

### Th?c h�nh 2
? **Validation ??y ??**:
- Ki?m tra d? li?u tr?ng
- Ki?m tra tr�ng m� khi th�m
- Th�ng b�o l?i chi ti?t

? **X? l� exception an to�n**:
- Try-Catch-Finally
- X? l� l?i r�ng bu?c kh�a ngo?i
- ?�ng k?t n?i t? ??ng

? **Giao di?n th�n thi?n**:
- Layout r� r�ng v?i GroupBox
- MessageBox x�c nh?n cho c�c thao t�c quan tr?ng
- Auto-load d? li?u khi m? form
- Click v�o d�ng ?? hi?n th? th�ng tin chi ti?t

? **Code s?ch v� c� t? ch?c**:
- T�ch bi?t logic k?t n?i
- Comment r� r�ng
- Tu�n th? chu?n C#

## ?? Lu?ng ho?t ??ng

### Th�m d? li?u:
```
Nh?p th�ng tin ? Validate ? Ki?m tra tr�ng m� ? Insert ? Reload ? Th�ng b�o
```

### S?a d? li?u:
```
Click ch?n ? Hi?n th? th�ng tin ? Ch?nh s?a ? X�c nh?n ? Update ? Reload ? Th�ng b�o
```

### X�a d? li?u:
```
Click ch?n ? X�c nh?n ? Ki?m tra r�ng bu?c ? Delete ? Reload ? Th�ng b�o
```

## ??? C�c ph??ng th?c ch�nh

### Form2.cs
- `MoKetNoi()`: M? k?t n?i SQL Server
- `DongKetNoi()`: ?�ng k?t n?i
- `LoadData()`: Load d? li?u t? database
- `ClearTextBoxes()`: X�a n?i dung c�c TextBox
- `btnThem_Click()`: X? l� th�m NXB
- `btnSua_Click()`: X? l� s?a NXB
- `btnXoa_Click()`: X? l� x�a NXB
- `btnLamMoi_Click()`: L�m m?i form
- `dgvDanhSach_CellClick()`: Hi?n th? th�ng tin khi click d�ng

## ?? Ghi ch�
- ?ng d?ng s? d?ng **Microsoft.Data.SqlClient** (khuy?n ngh? cho .NET 8)
- Kh�ng s? d?ng System.Data.SqlClient (?� l?i th?i)
- T?t c? c�c thao t�c ??u c� x? l� exception
- T? ??ng ?�ng k?t n?i trong finally block

## ?? M?c ti�u h?c t?p ??t ???c
? K?t n?i SQL Server t? WinForm  
? S? d?ng SqlDataAdapter v� DataSet  
? Th?c hi?n c�c thao t�c CRUD  
? X? l� exception v� validation  
? L�m vi?c v?i DataGridView  
? T?o giao di?n ng??i d�ng chuy�n nghi?p  

## ?? Li�n h?
- Email: [email c?a b?n]
- GitHub: [link GitHub c?a b?n]

---
**Ng�y ho�n th�nh**: [Ng�y hi?n t?i]
